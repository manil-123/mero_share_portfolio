enum Market { IPO, SECONDARY }
