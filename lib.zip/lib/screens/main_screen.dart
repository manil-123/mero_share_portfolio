import 'package:flutter/material.dart';
import 'package:mero_share_portfolio/models/share_data_provider.dart';
import 'package:mero_share_portfolio/screens/stock_list.dart';
import 'package:pie_chart/pie_chart.dart';
import 'dashboard.dart';
import 'package:provider/provider.dart';

class MainScreen extends StatefulWidget {
  @override
  _MainScreenState createState() => _MainScreenState();
}

class _MainScreenState extends State<MainScreen> {
  // String _totalInvestment;
  // double _profit;
  Future<int> totalInvestment;
  Future<double> profit;
  Map<String, double> dataMap = {
    'Banking': 4,
    'Development Bank': 5,
    'Finance': 2,
    'Hotel and Tourism': 3,
    'HydroPower': 1,
    'Life Insurance': 4,
    'Manufacturing and Processing': 2,
    'Microfinance': 2,
    'Non Life Insurance': 7,
  };
  List<Color> colorList = [
    Colors.red,
    Colors.yellow,
    Colors.green,
    Colors.redAccent,
    Colors.blueGrey,
    Colors.purple,
    Colors.black12,
    Colors.greenAccent,
    Colors.pink,
  ];

  Widget pieChart() {
    return PieChart(
      dataMap: dataMap,
      initialAngleInDegree: 0,
      animationDuration: Duration(milliseconds: 800),
      chartType: ChartType.disc,
      chartRadius: MediaQuery.of(context).size.width / 2.2,
      ringStrokeWidth: 32,
      colorList: colorList,
      chartLegendSpacing: 20,
      centerText: "Stocks",
      legendOptions: LegendOptions(
        showLegendsInRow: false,
        legendPosition: LegendPosition.right,
        showLegends: true,
        legendShape: BoxShape.circle,
        legendTextStyle: TextStyle(
          fontWeight: FontWeight.bold,
          fontSize: 8,
          color: Colors.black87,
        ),
      ),
      chartValuesOptions: ChartValuesOptions(
        showChartValueBackground: true,
        showChartValues: false,
        showChartValuesInPercentage: true,
        showChartValuesOutside: false,
        decimalPlaces: 1,
      ),
    );
  }

  @override
  void initState() {
    super.initState();
    this.totalInvestment =
        Provider.of<ShareDataProvider>(context, listen: false)
            .getTotalInvestment();
    this.profit = Provider.of<ShareDataProvider>(context, listen: false)
        .getTotalProfitLoss();
  }

  @override
  Widget build(BuildContext context) {
    // this._totalInvestment =
    //     Provider.of<ShareDataProvider>(context).totalInvestment;
    // this._profit = Provider.of<ShareDataProvider>(context).totalProfit;
    return Scaffold(
      appBar: AppBar(
        title: Text('My Portfolio'),
      ),
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: <Color>[
              Colors.lightBlueAccent,
              Colors.blueAccent,
            ],
          ),
        ),
        child: ListView(
          children: [
            SizedBox(
              height: 10,
            ),
            Center(
              child: Text(
                'Overall Stocks',
                style: TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                  color: Colors.white,
                ),
              ),
            ),
            SizedBox(
              height: 10,
            ),
            Container(
              width: MediaQuery.of(context).size.width,
              padding: EdgeInsets.all(5),
              child: pieChart(),
            ),
            Container(
              width: MediaQuery.of(context).size.width,
              padding: EdgeInsets.all(20),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Row(
                    children: [
                      Expanded(
                        child: Card(
                          elevation: 5,
                          margin: EdgeInsets.all(15),
                          child: InkWell(
                            onTap: () {
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (context) => DashBoard(),
                                ),
                              );
                            },
                            splashColor: Colors.greenAccent,
                            child: Center(
                              child: Padding(
                                padding: const EdgeInsets.all(16.0),
                                child: Column(
                                  children: [
                                    Text('My DashBoard'),
                                    SizedBox(
                                      height: 10,
                                    ),
                                    Text(''),
                                  ],
                                ),
                              ),
                            ),
                          ),
                        ),
                      ),
                      Expanded(
                        child: Card(
                          elevation: 5,
                          margin: EdgeInsets.all(15),
                          child: InkWell(
                            onTap: () {},
                            splashColor: Colors.greenAccent,
                            child: Center(
                              child: Padding(
                                padding: const EdgeInsets.all(16.0),
                                child: Column(
                                  children: [
                                    Text(
                                      'Overall Stocks',
                                      textAlign: TextAlign.center,
                                    ),
                                    SizedBox(
                                      height: 10,
                                    ),
                                    Text(
                                        '${Provider.of<ShareDataProvider>(context).shareDataCount}'),
                                  ],
                                ),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                  Row(
                    children: [
                      Expanded(
                        child: Card(
                          elevation: 5,
                          margin: EdgeInsets.all(10),
                          child: InkWell(
                            onTap: () {},
                            splashColor: Colors.greenAccent,
                            child: Center(
                              child: Padding(
                                padding: const EdgeInsets.all(16.0),
                                child: Column(
                                  children: [
                                    Text(
                                      'Total Investment',
                                      textAlign: TextAlign.center,
                                    ),
                                    SizedBox(
                                      height: 10,
                                    ),
                                    FutureBuilder<int>(
                                      future: totalInvestment, // async work
                                      builder: (BuildContext context,
                                          AsyncSnapshot<int> snapshot) {
                                        switch (snapshot.connectionState) {
                                          case ConnectionState.waiting:
                                            return SizedBox(
                                              width: 12,
                                              height: 12,
                                              child: CircularProgressIndicator(
                                                strokeWidth: 2,
                                                backgroundColor: Colors.red,
                                              ),
                                            );
                                          default:
                                            if (snapshot.hasError)
                                              return Text('Error');
                                            else
                                              return Text(
                                                  snapshot.data.toString());
                                        }
                                      },
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ),
                        ),
                      ),
                      Expanded(
                        child: Card(
                          elevation: 5,
                          margin: EdgeInsets.all(10),
                          child: InkWell(
                            onTap: () {},
                            splashColor: Colors.greenAccent,
                            child: Center(
                              child: Padding(
                                padding: const EdgeInsets.all(16.0),
                                child: Column(
                                  children: [
                                    Text(
                                      'Total Profit',
                                      textAlign: TextAlign.center,
                                    ),
                                    SizedBox(
                                      height: 10,
                                    ),
                                    FutureBuilder<double>(
                                      future: Provider.of<ShareDataProvider>(
                                              context)
                                          .getTotalProfitLoss(), // async work
                                      builder: (BuildContext context,
                                          AsyncSnapshot<double> snapshot) {
                                        switch (snapshot.connectionState) {
                                          case ConnectionState.waiting:
                                            return SizedBox(
                                              width: 12,
                                              height: 12,
                                              child: CircularProgressIndicator(
                                                strokeWidth: 2,
                                                backgroundColor: Colors.red,
                                              ),
                                            );
                                          default:
                                            if (snapshot.hasError)
                                              return Text('Error');
                                            else
                                              return Text(
                                                  snapshot.data.toString());
                                        }
                                      },
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            )
          ],
        ),
      ),
    );
  }

  Widget myCard(String heading, String value) {
    return Expanded(
      child: Card(
        elevation: 5,
        margin: EdgeInsets.all(15),
        child: InkWell(
          onTap: () {},
          splashColor: Colors.greenAccent,
          child: Center(
            child: Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                children: [
                  Text(
                    heading,
                    textAlign: TextAlign.center,
                  ),
                  SizedBox(
                    height: 10,
                  ),
                  value == "0.0"
                      ? SizedBox(
                          width: 32,
                          height: 32,
                          child: CircularProgressIndicator(
                            strokeWidth: 4,
                            backgroundColor: Colors.red,
                          ),
                        )
                      : Text('$value')
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
